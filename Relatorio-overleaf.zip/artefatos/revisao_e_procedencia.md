# Procedência e revisão do banco de especificações

## Procedência

As 30 especificações foram redigidas para este estudo, no contexto de uma biblioteca, com apoio de uma ferramenta conversacional de IA na elaboração inicial. Elas não foram transcritas do LeetCode, JavaBench ou de outro benchmark. O banco executado está preservado em `prompts_30_biblioteca.md`; a matriz `rastreabilidade_especificacoes.csv` liga cada ID aos conceitos e ao comportamento observável pedido.

O contexto da biblioteca foi mantido ao longo dos exercícios para reduzir a variação de vocabulário e do domínio da aplicação. A variação planejada está nos conceitos e comportamentos de OO: encapsulamento, estado, herança, interfaces, polimorfismo, coleções, composição, imutabilidade e tratamento de erros. Cada problema foi concebido como independente para permitir uma comparação pareada: todos os modelos recebem o mesmo enunciado e não herdam classes nem contexto de outras questões.

## Justificativa das escolhas

- **Java:** linguagem escolhida pelo autor para estudar os conceitos centrais de DOO. O material da disciplina recomenda explicitamente o recorte LLM/IA + Java/orientação a objetos. Java expressa classes, objetos, encapsulamento, herança e interfaces, além de permitir verificar compilação e execução com o JDK.
- **Três modelos locais:** seleção por viabilidade no computador disponível (Ryzen 7 5800U, 16 GB de RAM, sem GPU dedicada), disponibilidade no Ollama e possibilidade de comparar famílias/tamanhos distintos sob o mesmo ambiente local. Os modelos não foram selecionados como representantes de todo o mercado nem como os três melhores modelos disponíveis; trata-se de uma amostra intencional por conveniência e restrição de recursos. Diferenças observadas não podem ser atribuídas isoladamente ao tamanho, pois família, treinamento e tamanho variam juntos.
- **Role-playing:** o prompt fixo atribui a todos o mesmo papel de engenheiro Java e professor de OO. A escolha é coerente com a pergunta do estudo: verificar geração de código didático para tarefas de OO. O padrão Persona é descrito por White et al.; a aplicação à programação Java também dialoga com JavaBench, sem reutilizar suas especificações.

## Revisão de consistência realizada para a versão final

O banco congelado foi comparado com os seguintes critérios: (1) 30 IDs únicos; (2) uma tarefa independente por ID; (3) mesma mensagem de sistema e mesmo formato de saída para todos os modelos; (4) contexto Java autocontido em um único arquivo e classe pública `Main`; (5) comportamento demonstrável no `main`; e (6) cada item associado a pelo menos um conceito de OO/Java. A leitura do arquivo confirmou esses critérios gerais, e a matriz fornece o rastro item a item.

Esta verificação é uma revisão final de consistência do artefato, não uma validação independente por especialistas nem prova de que ocorreu antes da coleta. Não há registro de dupla revisão ou de concordância entre avaliadores. Para preservar a validade da comparação, os enunciados que foram efetivamente executados não foram alterados depois da geração dos 90 códigos.

## Ambiguidades observadas e limitação

Alguns enunciados deixam decisões de implementação em aberto. Por exemplo, P02 pede alterar o objeto original sem especificar uma operação mutadora; P12 e P20 exigem ISBN único, mas não fixam o comportamento exato para duplicidade; P18 pede representações distintas, sem definir se `enviar` retorna texto ou imprime. Essas escolhas podem criar variação entre respostas. Elas foram preservadas como parte do banco realmente avaliado e não foram corrigidas retroativamente. Uma nova versão dos enunciados exigiria repetir as 90 chamadas para continuar sendo comparável.

## Cobertura por blocos

- P01–P07: classes, encapsulamento, estado, invariantes, validação e exceções.
- P08–P10 e P16–P19: interfaces, herança, abstração, sobrescrita, polimorfismo e exceções próprias.
- P11–P15 e P20–P25: listas, mapas, filas, conjuntos, busca, ordenação, repositórios e histórico.
- P26–P30: composição, imutabilidade, agregação, abstração de regras e consistência entre objetos.

Esta distribuição é uma classificação do banco de prompts, não uma alegação de cobertura completa da disciplina ou do Java.
